# focus-meter
Google Chrome Extension to assist in focus
